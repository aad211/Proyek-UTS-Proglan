#ifndef BANTUAN
#define BANTUAN

void bantuan();

#endif
