#ifndef MENU_AAD
#define MENU_AAD

#define KIRI  0x4B  //ARROW KIRI 75
#define KANAN 0x4D //ARROW KANAN 77
#define ATAS  0x48  //ARROW ATAS 72
#define BAWAH 0x50 //ARROW BAWAH 80
#define ESC   0x1B //ESC 27
#define ENTER 0xD //enter 13

int arrow_menu();
void judul();
void judul_menu();
void submenu();

#endif
