#include<stdio.h>

void bantuan(){
	system("cls");
	printf("Urutkan Angka mulai dari 1-15\nPengerjaanya dimulai dari baris 1 dulu, jangan peduliin baris yang lain selain baris 1, setelah baris 1 jadi, maka setelah itu fokus ke baris 2 tanpa mengubah baris di atasnya\n");
	system("pause");
	menu();
}
